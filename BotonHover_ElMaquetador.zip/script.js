document.querySelector('.custom-buttom').addEventListener('click', function() {
  
  alert('¡Botón presionado - Sígueme en El Maquetador!');

}
);